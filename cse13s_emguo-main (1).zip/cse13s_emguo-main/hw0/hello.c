#include <stdio.h>

int main(void) {
    printf("Good morning!\n");
    return 0;
}
