# academic honesty statement, CSE13s Spring 2022

I understand that are we not to share code for this class.

I will type all of the code that I turn in and only share concepts and examples.

-- Emily Guo
